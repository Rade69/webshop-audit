# PROMPT — P0 Sprint #1: GUI testovi za Results i Review tok

Radiš na projektu **WebshopAudit**.

Prije rada obavezno pročitaj:
- `AGENTS_webshop_audit.md`
- `CLAUDE_webshop_audit.md`
- tehničku dokumentaciju za developera
- postojeće GUI integration testove
- nove GUI capability-je koji su već implementirani:
  - issue filter presets
  - explanation prikaz
  - evidence prikaz
  - impact badge / impact kolona

Ovo nije feature sprint.  
Ovo je **P0 stabilizacioni zadatak: GUI testovi**.

Ne radi GUI redesign.  
Ne dodaj nove featuree.  
Ne mijenjaj backend semantiku osim ako je minimalno nužno da testovi mogu pouzdano zaštititi postojeće ponašanje.

---

# 1. Cilj

Cilj je da Results i Review GUI tokovi dobiju **pravu regression zaštitu**, posebno za ono što je nedavno dodano:

- issue-centric filter workflow
- explainability prikaz
- evidence prikaz
- impact prikaz

Trenutno je najveći rizik da se ovo lako pokvari sitnim GUI izmjenama, a da niko ne primijeti na vrijeme.

Na kraju rada treba da važi:

- Results tok je testiran na integration nivou
- Review tok je testiran na integration nivou
- adapter + controller + prepared data rade konzistentno
- novi GUI capability-ji ne ostaju bez test zaštite

---

# 2. Najvažnije pravilo

**Ne praviti krhke click-automation testove bez potrebe.**

Ako puni widget click test nije stabilan ili je skup za održavanje:
- testiraj controller + adapter + state + prepared data

Ali test mora biti dovoljno blizu stvarnom GUI toku da zaista štiti ponašanje, ne samo helper funkcije.

---

# 3. Scope

Obavezno pregledaj:
- `gui/tabs/results_tab.py`
- `gui/tabs/review_queue_tab.py`
- `gui/controllers/results_controller.py`
- `gui/controllers/review_controller.py`
- `gui/adapters/results_adapter.py`
- `gui/adapters/review_adapter.py`
- postojeće GUI testove
- nove integration testove koji već postoje za audit lifecycle

---

# 4. Šta treba testirati

## 4.1. Results tab
Minimalno zaštiti:

### A. Issue filter presets
- izbor issue tipa filtrira prave URL-ove
- count-ovi, ako postoje u prikazu, ostaju konzistentni
- preset ne lomi postojeće checkbox filtere

### B. Detail panel explanation
- problematična stranica prikazuje human-readable explanation
- sample kandidat ne dobija isto objašnjenje kao pravi problem

### C. Detail panel evidence
- evidence summary je prisutan i formatiran
- GUI ne puca kad neki evidence field nedostaje

### D. Impact display
- impact je vidljiv za problematične stranice
- impact se ne miješa sa severity

---

## 4.2. Review Queue tab
Minimalno zaštiti:

### A. Detail panel explanation
- kandidat iz review reda prikazuje explanation

### B. Detail panel evidence
- kandidat iz review reda prikazuje evidence snapshot

### C. Impact signal
- impact badge/label/kolona ostaje konzistentna

### D. Review workflow stabilnost
- novi prikaz ne lomi postojeći note/status workflow

---

## 4.3. Cross-layer consistency
Testiraj da:
- Results i Review koriste isti source-of-truth za explanation
- Results i Review koriste isti source-of-truth za impact
- adapteri ne uvode lokalnu semantiku različitu od backend modula

---

# 5. Šta nije dozvoljeno

- ne uvoditi novi GUI feature set
- ne “popravljati” backend logiku samo da testovi prođu
- ne praviti 50 sitnih testova koji provjeravaju privatne detalje implementacije
- ne pretvarati ovo u full Qt automation projekat

---

# 6. Testovi koje očekujem

Dodaj ili ažuriraj testove za:

1. Results issue preset filtering
2. Results explanation rendering
3. Results evidence rendering
4. Results impact rendering
5. Review explanation rendering
6. Review evidence rendering
7. Review impact rendering
8. Cross-layer consistency (adapter/backend mapping)

---

# 7. Kriterij uspjeha

Zadatak je završen tek kad su ispunjeni svi uslovi:

- Results i Review tok imaju regression zaštitu za nove capability-je
- testovi su stabilni i brzi
- explanation/evidence/impact prikaz je pokriven
- issue filter preset je pokriven
- postojeći workflow nije slomljen

---

# 8. Očekivani izlaz od tebe

Vrati odgovor u ovom formatu:

## 1. Šta je bilo nepokriveno
## 2. Šta je sada dodano
## 3. Pogođeni fajlovi
## 4. Koji GUI tokovi su sada pokriveni
## 5. Među-zavisnosti provjerene
## 6. Rizici koji ostaju
## 7. Testovi
