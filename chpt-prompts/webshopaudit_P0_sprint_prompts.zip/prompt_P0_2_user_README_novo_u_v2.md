# PROMPT — P0 Sprint #2: User README / “Novo u v2.0”

Radiš na projektu **WebshopAudit**.

Prije rada obavezno pročitaj:
- `AGENTS_webshop_audit.md`
- `CLAUDE_webshop_audit.md`
- postojeće korisničko uputstvo
- postojeću tehničku dokumentaciju
- sve nove capability-je koji su implementirani u backendu i djelimično u GUI-u/reportu

Ovo nije tehnička arhitektonska dokumentacija.  
Ovo je **P0 user-facing dokumentacija** koja treba korisniku jasno pokazati šta je novo i zašto je korisno.

Ne radi GUI redesign.  
Ne piši marketinški tekst.  
Ne izmišljaj capability-je koji nisu stvarno implementirani.

---

# 1. Cilj

Cilj je da korisnici više ne budu u situaciji da:
- novi feature-i postoje
- ali niko ne zna da postoje
- niti zna kako da ih koristi

Potrebno je napraviti jasan README ili dodatak README-u sa sekcijom tipa:

- **Novo u v2.0**
- ili slično ime koje jasno komunicira promjene

Na kraju rada korisnik treba jasno razumjeti:
- koje su nove mogućnosti dodane
- gdje ih vidi u GUI-u / output fajlovima / reportu
- kako da ih koristi
- koja je razlika između starih i novih tokova

---

# 2. Najvažnije pravilo

**Dokument mora biti praktičan i tačan.**

Ne treba:
- duga teorija
- marketing copy
- obećavanja nečega što alat još nema

Treba:
- kratko objašnjenje
- gdje se feature vidi
- šta korisnik time dobija
- kada koristiti

---

# 3. Scope

Obavezno pregledaj:
- postojeći README
- postojeće korisničko uputstvo
- GUI rezultate i review tok
- output CSV fajlove
- report output
- nove capability module:
  - explainability
  - evidence
  - issue grouping
  - fix impact
  - run-to-run diff (ako je user-facing na bilo koji način)

---

# 4. Šta dokument mora pokriti

Minimalno očekujem sekcije:

## A. Šta je novo
Kratka lista novih capability-ja:
- human-readable objašnjenja
- evidence snapshot
- issue-centric pregled problema
- fix impact prioritizacija
- run-to-run poređenje (ako je dostupno korisniku)

## B. Gdje se to vidi
Za svaki feature napiši:
- GUI
- CSV output
- DOCX report
- CLI (ako postoji)

## C. Kako to koristiti
Na nivou korisnika:
- kad otvoriti Results
- kako koristiti issue filtere
- kako čitati explanation/evidence/impact
- kako čitati novu report sekciju

## D. Severity vs Impact
Obavezno objasni razliku:
- severity = koliko je nalaz ozbiljan u audit logici
- impact = koliko je korisno to prvo popraviti

## E. Primjeri
Daj 2–3 konkretna primjera tipa:
- “Nema cijene” → HIGH impact
- evidence pokazuje da schema price nedostaje
- explanation objašnjava zašto je to problem

---

# 5. Format

Može biti:
- update postojećeg README-a
ili
- novi markdown dokument tipa `README_v2_features.md`

Ako praviš novi dokument, ime mora biti jasno.

---

# 6. Šta nije dozvoljeno

- ne pisati tehničku arhitekturu
- ne pisati interni developer-only dokument
- ne preuveličavati feature-e
- ne spominjati stvari koje korisnik ne može stvarno vidjeti ili koristiti

---

# 7. Kriterij uspjeha

Zadatak je završen tek kad su ispunjeni svi uslovi:

- postoji user-facing dokument ili README update
- korisnik jasno vidi šta je novo
- korisnik razumije gdje se to vidi u alatu
- severity vs impact je jasno objašnjeno
- dokument je kratak, praktičan i tačan

---

# 8. Očekivani izlaz od tebe

Vrati odgovor u ovom formatu:

## 1. Koji dokument je napravljen ili ažuriran
## 2. Šta dokument pokriva
## 3. Koje nove funkcionalnosti su dokumentovane
## 4. Gdje korisnik vidi te funkcionalnosti
## 5. Rizici koji ostaju
