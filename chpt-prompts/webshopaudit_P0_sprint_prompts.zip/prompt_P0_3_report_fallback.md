# PROMPT — P0 Sprint #3: Report fallback kada issue_summary nedostaje

Radiš na projektu **WebshopAudit**.

Prije rada obavezno pročitaj:
- `AGENTS_webshop_audit.md`
- `CLAUDE_webshop_audit.md`
- `audit/report_generator.py`
- `audit/issue_grouping.py`
- postojeći report output i postojeće report integration testove

Ovo nije novi report feature sprint.  
Ovo je **P0 robustnost zadatak**: graceful fallback kad `issue_summary.csv` ili povezani issue-centric output nedostaju.

Ne radi veliki report redesign.  
Ne uvodi nove sekcije osim ako su nužne da fallback bude čist.  
Ne mijenjaj semantiku postojećih issue/impact prikaza bez jake potrebe.

---

# 1. Cilj

Cilj je da report generator ne bude krhak ako nedostaje neki od novih issue-centric output fajlova, posebno:

- `issue_summary.csv`
- eventualno povezani issue export podaci

Trenutno rizik je:
- novi report očekuje nove fajlove
- ako oni iz bilo kog razloga ne nastanu, report može:
  - puknuti
  - dati prazne / čudne sekcije
  - izgledati polomljeno

Na kraju rada treba da važi:

- report se generiše i kada issue summary nije dostupan
- fallback je jasan i graceful
- nema praznih ili polomljenih sekcija
- ako treba, report koristi minimalnu alternativu iz canonical scored podataka

---

# 2. Najvažnije pravilo

**Fallback ne smije lagati korisnika.**

Ako `issue_summary.csv` nedostaje:
- nemoj izmišljati pun issue summary kao da postoji
- ili jasno prikaži da sekcija nije dostupna
- ili izgradi ograničeni fallback iz pouzdanih canonical podataka

Ali mora biti jasno šta se desilo.

---

# 3. Scope

Obavezno pregledaj:
- `audit/report_generator.py`
- `audit/exporters.py`
- `audit/issue_grouping.py`
- postojeće report integration testove
- output directory očekivanja

Po potrebi pregledaj i:
- `products_scored.csv`
- `manual_review_candidates.csv`

---

# 4. Šta treba uraditi

## A. Učiniti issue summary sekciju otpornom
Ako `issue_summary.csv` postoji:
- koristi ga kao primarni source

Ako ne postoji:
- koristi ograničeni fallback iz canonical scored outputa
ili
- preskoči sekciju uz jasan, čist tekstualni fallback

## B. Učiniti impact prioritet sekciju otpornom
Ako issue summary nedostaje, a impact mapping postoji drugdje:
- koristi ono što je pouzdano dostupno

Ako nije moguće:
- ne rušiti report
- dati skraćenu sekciju ili preskočiti je kontrolisano

## C. Izbjeći prazne/polomljene dijelove reporta
Ne smije ostati:
- prazna tabela
- naslov bez sadržaja
- traceback / exception
- placeholder koji izgleda kao bug

---

# 5. Pravila fallback ponašanja

Prihvatljive varijante su:

### Varijanta 1 — synthetic fallback
Iz `products_scored.csv` izračunaj ograničeni minimalni issue summary za najvažnije issue tipove

### Varijanta 2 — graceful skip
Ako nema dovoljno podataka, preskoči issue summary sekciju i ostavi jasan, kratak fallback tekst

Odaberi ono što je čistije i sigurnije.

---

# 6. Šta nije dozvoljeno

- ne duplirati cijelu issue grouping logiku unutar reporta
- ne uvoditi komplikovan fallback engine
- ne praviti sekcije koje izgledaju “popunjeno”, a zapravo nisu pouzdane
- ne širiti scope na novi report dizajn

---

# 7. Testovi

Dodaj ili ažuriraj testove za scenarije:

1. `issue_summary.csv` postoji → report koristi puni issue summary
2. `issue_summary.csv` nedostaje → report ne puca
3. `issue_summary.csv` nedostaje → fallback/skip ponašanje je čisto
4. impact sekcija ne lomi report kad nema issue summary
5. report i dalje generiše validan DOCX output

---

# 8. Kriterij uspjeha

Zadatak je završen tek kad su ispunjeni svi uslovi:

- report generator je robustan na nedostajući issue summary output
- fallback ponašanje je čisto i pošteno
- nema polomljenih sekcija
- testovi štite ove scenarije

---

# 9. Očekivani izlaz od tebe

Vrati odgovor u ovom formatu:

## 1. Koji je bio problem
## 2. Šta je sada promijenjeno
## 3. Pogođeni fajlovi
## 4. Kako radi fallback
## 5. Među-zavisnosti provjerene
## 6. Rizici koji ostaju
## 7. Testovi
